package com.mycompany.lotoski.lautaro.emilio.recuperatorio.progii321;

public class RegistroSensor extends EvidenciaTecnica implements Informable {

    private final double frecuenciaDetectada;

    public RegistroSensor(String codigo, String agencia, NivelClasificacion clasificacion, String fechaObtencion,
            int confiabilidad, double frecuenciaDetectada) {

        super(fechaObtencion, confiabilidad, codigo, agencia, clasificacion);

        this.frecuenciaDetectada = frecuenciaDetectada;
    }

    public double getFrecuenciaDetectada() {
        return frecuenciaDetectada;
    }

    @Override
    public String generarInforme() {
        return "Informe tecnico del registro " + getCodigo()
                + ": frecuencia detectada " + frecuenciaDetectada + " MHz.";
    }

    @Override
    public String toString() {
        return "RegistroSensor [codigo=" + getCodigo()
                + ", agencia=" + getAgencia()
                + ", clasificacion=" + getClasificacion()
                + ", fechaObtencion=" + getFechaObtencion()
                + ", confiabilidad=" + getConfiabilidad()
                + ", frecuenciaDetectada=" + frecuenciaDetectada + " MHz]";
    }
}
