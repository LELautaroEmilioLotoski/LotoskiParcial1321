package com.mycompany.lotoski.lautaro.emilio.recuperatorio.progii321;

import java.util.Objects;

public abstract class ArchivoExtraterrestre {
    
    private final String codigo;
    private final String agencia;
    private final NivelClasificacion clasificacion;
    
    public ArchivoExtraterrestre(String codigo, String agencia, NivelClasificacion clasificacion) {
        Validaciones.validarStringIngresado(codigo, "El codigo no puede ser null");
        Validaciones.validarStringIngresado(agencia, "La agencia no puede ser null");
        Validaciones.validarNivelIngresado(clasificacion);
        this.codigo = codigo;
        this.agencia = agencia;
        this.clasificacion = clasificacion;
    }
    
    public String getCodigo() {
        return codigo;
    }
    
    public String getAgencia() {
        return agencia;
    }
    
    public NivelClasificacion getClasificacion() {
        return clasificacion;
    }
    
    @Override
    public boolean equals(Object obj) {
        
        if (this == obj) {
            return true;
        }
        
        if (!(obj instanceof ArchivoExtraterrestre otra)) {
            return false;
        }
        
        return codigo.equals(otra.codigo)
                && agencia.equals(otra.agencia);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(codigo, agencia);
    }
    
}
