package com.mycompany.lotoski.lautaro.emilio.recuperatorio.progii321;

public class TestimonioClasificado extends ArchivoExtraterrestre implements Informable {
    private String aliasTestigo;

    public TestimonioClasificado(String codigo, String agencia, NivelClasificacion clasificacion, String aliasTestigo) {
        super(codigo, agencia, clasificacion);
        Validaciones.validarStringIngresado(aliasTestigo, "El alias del testigo no puede ser null");
        this.aliasTestigo = aliasTestigo;
    }

    public String getAliasTestigo() {
        return aliasTestigo;
    }

    @Override
    public String generarInforme() {
        return "Informe del testimonio " + getCodigo()
                + ": testigo identificado mediante el alias '" + aliasTestigo + "'.";
    }

    @Override
    public String toString() {
        return "TestimonioClasificado [codigo=" + getCodigo()
                + ", agencia=" + getAgencia()
                + ", clasificacion=" + getClasificacion()
                + ", aliasTestigo=" + aliasTestigo + "]";
    }
}