
package com.mycompany.lotoski.lautaro.emilio.recuperatorio.progii321;

public enum NivelClasificacion {
    PUBLICO,
    RESERVADO,
    ULTRASECRETO
}
