
    package com.mycompany.lotoski.lautaro.emilio.recuperatorio.progii321;

    public interface Informable {
        String generarInforme();
    }
