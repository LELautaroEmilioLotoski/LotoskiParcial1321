
package com.mycompany.lotoski.lautaro.emilio.recuperatorio.progii321;


public interface Analizable {
    String analizar();
}
