package com.mycompany.lotoski.lautaro.emilio.recuperatorio.progii321;

import java.util.ArrayList;
import java.util.List;

public class ArchivoDesclasificado {

    private final String nombre;
    private final List<ArchivoExtraterrestre> archivos;

    public ArchivoDesclasificado(String nombre) {
        Validaciones.validarStringIngresado(nombre,"El valor del nombre no puede ser null");

        this.nombre = nombre;
        this.archivos = new ArrayList<>();
    }

    public void agregarArchivo(ArchivoExtraterrestre archivo) {
        validarArchivoDuplicado(archivo);
        archivos.add(archivo);
    }

    private void validarArchivoDuplicado(ArchivoExtraterrestre archivo) {
        if (archivos.contains(archivo)) {
            throw new ArchivoDuplicadoException(
                    "Ya existe un archivo con codigo '"
                    + archivo.getCodigo()
                    + "' perteneciente a la agencia '"
                    + archivo.getAgencia() + "'."
            );
        }
    }

    public List<ArchivoExtraterrestre> obtenerArchivos() {
        return new ArrayList<>(archivos);
    }

    public List<ArchivoExtraterrestre> filtrarPorClasificacion(NivelClasificacion nivel) {
        Validaciones.validarNivelIngresado(nivel);
        List<ArchivoExtraterrestre> clasificacionFiltrada = new ArrayList<>();

        for (ArchivoExtraterrestre archivo : archivos) {
            if (archivo.getClasificacion() == nivel) {
                clasificacionFiltrada.add(archivo);
            }
        }

        return clasificacionFiltrada;
    }
}
