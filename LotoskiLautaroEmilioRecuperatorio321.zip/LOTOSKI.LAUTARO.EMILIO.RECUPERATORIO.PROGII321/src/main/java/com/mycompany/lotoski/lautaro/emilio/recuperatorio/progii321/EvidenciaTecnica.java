package com.mycompany.lotoski.lautaro.emilio.recuperatorio.progii321;

    public abstract class EvidenciaTecnica extends ArchivoExtraterrestre
        implements Analizable {

    private String fechaObtencion;

    private static final int CONFIABILIDAD_MINIMA = 0;
    private static final int CONFIABILIDAD_MAXIMA = 100;
    private int confiabilidad;

    public EvidenciaTecnica(String fechaObtencion, int confiabilidad, String codigo, String agencia,
            NivelClasificacion clasificacion) {
        super(codigo, agencia, clasificacion);

        Validaciones.validarStringIngresado(fechaObtencion, "La fecha de obtencion no puede ser null");
        validarConfiabilidad(confiabilidad);
        this.fechaObtencion = fechaObtencion;
        this.confiabilidad = confiabilidad;
    }

    public String getFechaObtencion() {
        return fechaObtencion;
    }

    public int getConfiabilidad() {
        return confiabilidad;
    }

    private void validarConfiabilidad(int confiabilidadIngresada) {
        if (confiabilidadIngresada < CONFIABILIDAD_MINIMA || confiabilidadIngresada > CONFIABILIDAD_MAXIMA) {
            throw new IllegalArgumentException(
                    "La confiabilidad debe estar entre 0 y 100");
        }
    }

    @Override
    public String analizar() {
        return "Se analizo la evidencia "
                + getCodigo()
                + " con un nivel de confiabilidad de "
                + confiabilidad + "%.";
    }
}
