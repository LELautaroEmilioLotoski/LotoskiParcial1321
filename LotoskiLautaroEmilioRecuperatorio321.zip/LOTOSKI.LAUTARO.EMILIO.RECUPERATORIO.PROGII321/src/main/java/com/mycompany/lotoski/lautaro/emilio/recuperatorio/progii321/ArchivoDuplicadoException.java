package com.mycompany.lotoski.lautaro.emilio.recuperatorio.progii321;

public class ArchivoDuplicadoException extends RuntimeException {

    public ArchivoDuplicadoException() {
    }

    public ArchivoDuplicadoException(String msg) {
        super(msg);
    }
}