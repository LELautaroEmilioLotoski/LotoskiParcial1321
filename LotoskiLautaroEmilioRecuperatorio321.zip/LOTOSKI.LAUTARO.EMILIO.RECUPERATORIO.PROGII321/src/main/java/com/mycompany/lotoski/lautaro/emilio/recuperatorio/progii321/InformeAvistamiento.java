package com.mycompany.lotoski.lautaro.emilio.recuperatorio.progii321;

public class InformeAvistamiento extends EvidenciaTecnica {

    private String ubicacion;

    public InformeAvistamiento(String codigo, String agencia, NivelClasificacion clasificacion,
            String fechaObtencion, int confiabilidad, String ubicacion) {
        super(fechaObtencion, confiabilidad, codigo, agencia, clasificacion);
        Validaciones.validarStringIngresado(ubicacion, "La ubicacion no puede ser null");

        this.ubicacion = ubicacion;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    @Override
    public String toString() {
        return "InformeAvistamiento [codigo=" + getCodigo()
                + ", agencia=" + getAgencia()
                + ", clasificacion=" + getClasificacion()
                + ", fechaObtencion=" + getFechaObtencion()
                + ", confiabilidad=" + getConfiabilidad()
                + ", ubicacion=" + ubicacion + "]";
    }
}
