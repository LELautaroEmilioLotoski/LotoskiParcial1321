package com.mycompany.lotoski.lautaro.emilio.recuperatorio.progii321;

public class Validaciones {

    public static void validarStringIngresado(String str, String mensaje) {
        if (str == null || str.isBlank()) {
            throw new IllegalArgumentException(mensaje);
        }
    }

    public static void validarNivelIngresado(NivelClasificacion nivelClasificacionIngresado) {
        if (nivelClasificacionIngresado == null) {
            throw new IllegalArgumentException("El nivel ingresado no puede ser null");
        }
    }
    

}
