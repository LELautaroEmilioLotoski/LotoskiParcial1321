package com.mycompany.lotoski.lautaro.emilio.parcial.progii321;

import java.util.List;
import java.util.ArrayList;
import java.lang.IllegalArgumentException;

public class CentroEntrenamiento {

    private final String nombre;
    private final List<Actividad> actividades;

    public CentroEntrenamiento(String nombre) {
        Validaciones.validarStringIngresado(nombre, "El nombre ingresado es invalido");

        this.nombre = nombre;
        this.actividades = new ArrayList<>();
    }

    /**
     * Agrega una actividad al centro de entrenamiento. Verifica que la
     * actividad sea válida y que no exista previamente una actividad duplicada.
     *
     * @param actividad actividad a registrar.
     * @throws IllegalArgumentException si la actividad es inválida.
     * @throws ActividadDuplicadaException si ya existe una actividad con el
     * mismo nombre y entrenador.
     */
    public void agregarActividad(Actividad actividad) throws ActividadDuplicadaException {
        Validaciones.validarActividadIngresada(actividad);
        validarActividadDuplicada(actividad);
        actividades.add(actividad);
    }

    /**
     * Verifica si la actividad ya se encuentra registrada dentro del centro de
     * entrenamiento.
     *
     * @param actividad actividad a validar.
     * @throws ActividadDuplicadaException si la actividad ya existe.
     */
    private void validarActividadDuplicada(Actividad actividad) {
        if (actividades.contains(actividad)) {
            throw new ActividadDuplicadaException(
                    "Ya existe una actividad con nombre '"
                    + actividad.getNombre()
                    + "' y entrenador '"
                    + actividad.getEntrenador() + "'."
            );
        }
    }

    /**
     * Obtiene una copia de la lista de actividades registradas.
     *
     * @return lista con las actividades del centro.
     */
    public List<Actividad> obtenerActividades() {
        return new ArrayList<>(actividades);
    }

    /**
     * Filtra las actividades según el nivel de intensidad indicado.
     *
     * @param nivel nivel de intensidad a buscar.
     * @return lista de actividades que coinciden con el nivel solicitado.
     * @throws IllegalArgumentException si el nivel es nulo.
     */
    public List<Actividad> filtrarPorNivel(NivelIntensidad nivel) {
        Validaciones.validarNivelIngresado(nivel);
        List<Actividad> actividadFiltrada = new ArrayList<>();

        for (Actividad actividad : actividades) {
            if (actividad.getIntensidad() == nivel) {
                actividadFiltrada.add(actividad);
            }
        }

        return actividadFiltrada;
    }

}
