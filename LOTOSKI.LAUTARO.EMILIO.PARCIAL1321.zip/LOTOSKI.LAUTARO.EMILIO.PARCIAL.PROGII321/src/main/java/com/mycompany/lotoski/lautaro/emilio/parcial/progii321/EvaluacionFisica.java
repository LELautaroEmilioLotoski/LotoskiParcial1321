package com.mycompany.lotoski.lautaro.emilio.parcial.progii321;

public class EvaluacionFisica extends Actividad implements GeneradorInforme {

    private static final int PUNTAJE_MINIMO = 0;
    private static final int PUNTAJE_MAXIMO = 100;
    private final int puntaje;

    /**
     * Crea una nueva evaluación física.
     *
     * @param nombre nombre de la evaluación.
     * @param entrenador entrenador responsable.
     * @param intensidad nivel de intensidad asociado a la evaluación.
     * @param puntaje puntaje obtenido en la evaluación.
     * @throws IllegalArgumentException si el puntaje está fuera del rango
     * permitido.
     */
    public EvaluacionFisica(String nombre, String entrenador, NivelIntensidad intensidad, int puntaje) {
        super(nombre, entrenador, intensidad);

        validarPuntaje(puntaje);
        this.puntaje = puntaje;
    }

    /**
     * Verifica que el puntaje se encuentre dentro del rango permitido.
     *
     * @param puntajeRecibido puntaje a validar.
     * @throws IllegalArgumentException si el puntaje es menor que 0 o mayor que
     * 100.
     */
    private void validarPuntaje(int puntajeRecibido) {
        if (puntajeRecibido < PUNTAJE_MINIMO || puntajeRecibido > PUNTAJE_MAXIMO) {
            throw new IllegalArgumentException("El puntaje ingresado debe estar entre " + PUNTAJE_MINIMO + " y " + PUNTAJE_MAXIMO);
        }
    }

    @Override
    public String generarInforme() {
        return "Informe de evaluacion fisica: "
                + getNombre()
                + ". Puntaje obtenido: "
                + puntaje
                + "/100.";
    }

    @Override
    public String toString() {
        return "EvaluacionFisica ["
                + "nombre=" + getNombre()
                + ", entrenador=" + getEntrenador()
                + ", intensidad=" + getIntensidad()
                + ", puntaje=" + puntaje
                + "]";
    }

}
