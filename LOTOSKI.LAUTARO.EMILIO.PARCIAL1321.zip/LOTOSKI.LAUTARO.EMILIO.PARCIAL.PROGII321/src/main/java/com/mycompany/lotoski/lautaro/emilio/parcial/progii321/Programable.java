
package com.mycompany.lotoski.lautaro.emilio.parcial.progii321;

public interface Programable {
    String programar();
}
