package com.mycompany.lotoski.lautaro.emilio.parcial.progii321;

public class ClaseGrupal extends Actividad implements Programable {

    private final int cantidadMaximaDeParticipante;

    /**
     * Crea una nueva clase grupal.
     *
     * @param nombre nombre de la actividad.
     * @param entrenador entrenador responsable.
     * @param intensidad nivel de intensidad de la actividad.
     * @param cantidadMaximaDeParticipante cantidad máxima de participantes
     * permitidos.
     * @throws IllegalArgumentException si la cantidad máxima de participantes
     * es menor o igual a cero.
     */
    public ClaseGrupal(String nombre, String entrenador, NivelIntensidad intensidad, int cantidadMaximaDeParticipante) {
        super(nombre, entrenador, intensidad);

        validarCantidadMaximaDeParticipante(cantidadMaximaDeParticipante);
        this.cantidadMaximaDeParticipante = cantidadMaximaDeParticipante;
    }

    /**
     * Verifica que la cantidad máxima de participantes sea válida.
     *
     * @param cantidadMaximaDeParticipante cantidad a validar.
     * @throws IllegalArgumentException si la cantidad es menor o igual a cero.
     */
    private void validarCantidadMaximaDeParticipante(int cantidadMaximaDeParticipante) {
        if (cantidadMaximaDeParticipante <= 0) {
            throw new IllegalArgumentException("La cantidad de participantes ingresada esta fuera del rango permitido");
        }
    }

    @Override
    public String programar() {
        return "Se programo la clase grupal: " + getNombre();
    }

    @Override
    public String toString() {
        return "ClaseGrupal [nombre=" + getNombre()
                + ", entrenador=" + getEntrenador()
                + ", intensidad=" + getIntensidad()
                + ", maxParticipantes=" + cantidadMaximaDeParticipante + "]";
    }

}
