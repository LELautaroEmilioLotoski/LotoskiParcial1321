package com.mycompany.lotoski.lautaro.emilio.parcial.progii321;

public class Validaciones {

    /**
     * Verifica que una cadena de texto no sea nula ni esté vacía.
     *
     * @param str cadena a validar.
     * @param mensaje mensaje de error a mostrar en caso de validación fallida.
     * @throws IllegalArgumentException si la cadena es nula o está vacía.
     */
    public static void validarStringIngresado(String str, String mensaje) {
        if (str == null || str.isBlank()) {
            throw new IllegalArgumentException(mensaje);
        }
    }

    /**
     * Verifica que el nivel de intensidad recibido no sea nulo.
     *
     * @param nivelIngresado nivel de intensidad a validar.
     * @throws IllegalArgumentException si el nivel es nulo.
     */
    public static void validarNivelIngresado(NivelIntensidad nivelIngresado) {
        if (nivelIngresado == null) {
            throw new IllegalArgumentException("El nivel ingresado no puede ser null");
        }
    }

    /**
     * Verifica que la actividad recibida no sea nula.
     *
     * @param actividad actividad a validar.
     * @throws IllegalArgumentException si la actividad es nula.
     */

    public static void validarActividadIngresada(Actividad actividad) {
        if (actividad == null) {
            throw new IllegalArgumentException("La actividad no puede ser null");
        }
    }

}
