package com.mycompany.lotoski.lautaro.emilio.parcial.progii321;

import java.util.Objects;

abstract public class Actividad {

    private final String nombre;
    private final String entrenador;
    private final NivelIntensidad intensidad;

    public Actividad(String nombre, String entrenador, NivelIntensidad intensidad) {
        Validaciones.validarStringIngresado(nombre, "El nombre de la actividad ingresada no es valida");
        Validaciones.validarNivelIngresado(intensidad);
        Validaciones.validarStringIngresado(entrenador, "El entrenador ingresado no es valido");
        
        this.nombre = nombre;
        this.entrenador = entrenador;
        this.intensidad = intensidad;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEntrenador() {
        return entrenador;
    }

    public NivelIntensidad getIntensidad() {
        return intensidad;
    }

    @Override
    public boolean equals(Object obj) {

        if (this == obj) return true;

        if (obj == null || !(obj instanceof Actividad)) {
            return false;
        }

        Actividad otra = (Actividad) obj;

        return nombre.equals(otra.nombre)
                && entrenador.equals(otra.entrenador);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, entrenador);
    }

}
