package com.mycompany.lotoski.lautaro.emilio.parcial.progii321;

public class RutinaPersonalizada extends Actividad implements Programable, GeneradorInforme {

    private final int duracionEstimada;

    /**
     * Crea una nueva rutina personalizada.
     *
     * @param nombre nombre de la rutina.
     * @param entrenador entrenador responsable.
     * @param intensidad nivel de intensidad de la rutina.
     * @param duracionEstimada duración estimada en semanas.
     * @throws IllegalArgumentException si la duración es menor o igual a cero.
     */
    
    public RutinaPersonalizada(String nombre, String entrenador, NivelIntensidad intensidad, int duracionEstimada) {
        super(nombre, entrenador, intensidad);

        validarDuracionEstimada(duracionEstimada);
        this.duracionEstimada = duracionEstimada;
    }

    /**
     * Verifica que la duración estimada sea válida.
     *
     * @param duracionIngresada duración a validar.
     * @throws IllegalArgumentException si la duración es menor o igual a cero.
     */
    private void validarDuracionEstimada(int duracionIngresada) {
        if (duracionIngresada <= 0) {
            throw new IllegalArgumentException("La duracion estimada debe ser mayor a 0");
        }
    }

    @Override
    public String programar() {
        return "Se programo la rutina personalizada: " + getNombre();
    }

    @Override
    public String generarInforme() {
        return "Informe de rutina personalizada: "
                + getNombre()
                + ". Duracion estimada: "
                + duracionEstimada
                + " semanas.";
    }

    @Override
    public String toString() {
        return "RutinaPersonalizada ["
                + "nombre=" + getNombre()
                + ", entrenador=" + getEntrenador()
                + ", intensidad=" + getIntensidad()
                + ", duracionSemanas=" + duracionEstimada
                + "]";
    }

}
