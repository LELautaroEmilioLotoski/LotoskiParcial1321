
package com.mycompany.lotoski.lautaro.emilio.parcial.progii321;

public interface GeneradorInforme {
     String generarInforme();
}
