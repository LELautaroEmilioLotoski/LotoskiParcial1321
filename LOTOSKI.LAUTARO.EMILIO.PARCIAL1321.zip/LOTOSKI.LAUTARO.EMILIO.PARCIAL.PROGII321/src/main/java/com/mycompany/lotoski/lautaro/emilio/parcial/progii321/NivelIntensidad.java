
package com.mycompany.lotoski.lautaro.emilio.parcial.progii321;

public enum NivelIntensidad {
    BAJA,
    MEDIA,
    ALTA
}
