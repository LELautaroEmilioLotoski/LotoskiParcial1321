package com.mycompany.lotoski.lautaro.emilio.parcial.progii321;

import java.util.List;

public class LOTOSKILAUTAROEMILIOPARCIALPROGII321 {

    public static void main(String[] args) {
        CentroEntrenamiento centro = new CentroEntrenamiento("Alto Rendimiento Sur");
        try {
            centro.agregarActividad(
                    new ClaseGrupal("Funcional", "Laura Gomez", NivelIntensidad.ALTA, 25)
            );
            centro.agregarActividad(
                    new RutinaPersonalizada("Plan Fuerza Inicial", "Martin Diaz",
                            NivelIntensidad.MEDIA, 8)
            );
            centro.agregarActividad(
                    new EvaluacionFisica("Evaluacion Ingreso", "Carla Suarez",
                            NivelIntensidad.BAJA, 78)
            );
            centro.agregarActividad(
                    new RutinaPersonalizada("Plan Resistencia", "Laura Gomez",
                            NivelIntensidad.ALTA, 6)
            );
            centro.agregarActividad(
                    new ClaseGrupal("Funcional", "Laura Gomez", NivelIntensidad.MEDIA, 20)
            );
        } catch (ActividadDuplicadaException e) {
            System.out.println("No se pudo agregar la actividad: " + e.getMessage());
        }

        System.out.println("Actividades registradas:");
        mostrarActividades(centro.obtenerActividades());
        System.out.println();
        System.out.println("Actividades programables:");
        programarActividades(centro.obtenerActividades());
        System.out.println();
        System.out.println("Informes generados:");
        generarInformesDesdeMain(centro.obtenerActividades());
        System.out.println();
        System.out.println("Actividades de intensidad ALTA:");
        mostrarActividades(centro.filtrarPorNivel(NivelIntensidad.ALTA));
    }

    /**
     * Muestra por consola las actividades recibidas. Si la lista está vacía,
     * informa que no hay actividades disponibles.
     *
     * @param actividades lista de actividades a mostrar.
     */
    private static void mostrarActividades(List<Actividad> actividades) {

        if (actividades.isEmpty()) {
            System.out.println("No hay actividades disponibles para mostrar.");
        } else {
            for (Actividad act : actividades) {
                System.out.println(act);
            }
        }

    }

    /**
     * Programa todas las actividades que implementan la interfaz Programable.
     * En caso contrario, informa que la actividad no puede programarse.
     *
     * @param actividades lista de actividades a procesar.
     */
    private static void programarActividades(List<Actividad> actividades) {

        for (Actividad actividad : actividades) {

            if (actividad instanceof Programable programable) {
                System.out.println(programable.programar());
            } else {
                System.out.println(
                        "La actividad '" + actividad.getNombre()
                        + "' no puede programarse."
                );
            }
        }
    }

    /**
     * Genera y muestra los informes de las actividades que implementan la
     * interfaz GeneradorInforme. Si una actividad no genera informes, se
     * informa por consola.
     *
     * @param actividades lista de actividades a procesar.
     */
    private static void generarInformesDesdeMain(List<Actividad> actividades) {

        for (Actividad actividad : actividades) {
            if (actividad instanceof GeneradorInforme generarInforme) {
                System.out.println(generarInforme.generarInforme());
            } else {

                System.out.println(
                        "La actividad '"
                        + actividad.getNombre()
                        + "' no genera informe."
                );

            }
        }
    }

}
