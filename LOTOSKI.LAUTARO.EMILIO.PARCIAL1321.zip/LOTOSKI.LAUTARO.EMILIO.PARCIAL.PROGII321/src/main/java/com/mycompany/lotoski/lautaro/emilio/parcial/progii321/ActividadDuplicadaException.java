
package com.mycompany.lotoski.lautaro.emilio.parcial.progii321;

public class ActividadDuplicadaException extends RuntimeException {

    public ActividadDuplicadaException(String message) {
        super(message);
    }

}
